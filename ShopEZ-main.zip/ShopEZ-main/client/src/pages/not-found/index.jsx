

function NotFound(){
    return (
        <div>page does't exist</div>
    );
}

export default NotFound;